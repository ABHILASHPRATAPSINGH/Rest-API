import base64
from wsgiref.util import FileWrapper

from django.shortcuts import render
from requests import Response
from secondapp.models import Employee
from secondapp.models import Stock
from secondapp import utility

from django.views.generic import View
from django.http import HttpResponse, JsonResponse
import json


def view_cal(request):
    return render(request, 'secondapp/result.html')

def view_addStockToDB(request):
    Stock.objects.all().delete()
    rate=utility.rCurrentStockPriceInfoWeb()
    delivery=utility.rCurrentStockVolDelInfoWeb()
    stock_data=utility.mergeData(rate,delivery)
    populate_Data(stock_data)
    s = '<h1>Data added to database!!!</h1>'
    return HttpResponse(s)

def view_Stock(request):
    stock = Stock.objects.all()
    mydict = {'stock': stock}
    return render(request, 'secondapp/Stock.html',mydict)

def populate_Data(stockDataframe):
    # 'Price','Previous Price','Rate'
    for i in range(len(stockDataframe)):
        Stock.objects.create(sname=stockDataframe.loc[i,'Name'],sprice=stockDataframe.loc[i,'Price_x'],srate=stockDataframe.loc[i,'Rate'],svol=stockDataframe.loc[i,'Volume_x'],sdel=stockDataframe.loc[i,'% Del'])

def view_getEmployee(request):
    employeeInfo=Employee.objects.all()
    mydict={'employees':employeeInfo}
    return render(request,'secondapp/table.html',mydict)

# def EmployeeDetailsFunctionBased(request):
#     emp_Data={
#     'Id':1,
#     'Name':'ABH',
#     'Salary':1000,
#     'Address':'Delhi'
#     }
#     json_Data=json.dumps(emp_Data)
#     return HttpResponse(json_Data,content_type='application/json')
#
class EmployeeDetailsClassBased(View):

    def get(self,request,*args,**kwargs):
        # 'emp=Employee.objects.get(id=1)
        pdfPath=r"C:\Users\DELL\PycharmProjects\djangoPro1\Day 1 Introduction and Placing Fingers.pdf"
        short_report = open(pdfPath, 'rb')
        fileWrapper=FileWrapper(short_report)
        encodedFileWrapper= base64.b64encode(short_report.read()).decode("utf-8")

        emp_Data={
        'Id':1,
        'Name':'CHI',
        'Salary':1000,
        'Address':'Ghaziabad'
        ,"file": encodedFileWrapper
        }
        #
        # d={}
        # d["file"]=encodedFileWrapper
        # return JsonResponse(d)
        # response = HttpResponse(fileWrapper, content_type='application/pdf')
        # return response
        json_Data=json.dumps(emp_Data)
        return HttpResponse(json_Data,content_type='application/json')
        # return HttpResponse(encodedFileWrapper)
