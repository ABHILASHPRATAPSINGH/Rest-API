import requests
import json

BASE_URL='http://127.0.0.1:8000'
END_POINT='/api/2/'

resp=requests.get(BASE_URL+END_POINT)
emp_data=resp.json()
print(emp_data)