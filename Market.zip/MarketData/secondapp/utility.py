import requests,bs4
import pandas

# from MarketData.secondapp import utility

def rCurrentStockPriceInfoWeb():
    hdr = {"user-agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/90.0.4430.93 Safari/537.36 Edg/90.0.818.56"}
    URL_lst = ["https://www.financialexpress.com/market/stock-market/nse-top-gainers/"]
    df = []
    for url in URL_lst:
        resp = requests.get(url, headers=hdr)
        soup = bs4.BeautifulSoup(resp.text, 'html.parser')
        table = soup.find(id='modality')
        for tr in table.find_all('tr'):
            lst = []
            for td in tr.find_all('td'):
                lst.append(td.text)
            df.append(lst)

    df=pandas.DataFrame(df,columns=['Name','Price','Previous Price','Rate','Change Price','Volume'])
    df_rate=df.drop([0])
    return df_rate

def rCurrentStockVolDelInfoWeb():
    hdr = {"user-agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/90.0.4430.93 Safari/537.36 Edg/90.0.818.56"}
    URL_lst = ["https://www.financialexpress.com/market/stock-market/nse-low-delivery/"]
    df = []
    for url in URL_lst:
        resp = requests.get(url, headers=hdr)
        soup = bs4.BeautifulSoup(resp.text, 'html.parser')
        table = soup.find(id='modality')
        for tr in table.find_all('tr'):
            lst = []
            for td in tr.find_all('td'):
                lst.append(td.text)
            df.append(lst)

    df=pandas.DataFrame(df,columns=['Name','Volume','Delivery Volume','% Del','Price'])
    df_delivery=df.drop([0])
    return df_delivery

def mergeData(df_rate,df_delivery):
    df=pandas.merge(df_rate,df_delivery,on='Name',how='left')
    df=df.fillna(0.00)
    return df



