import json
import requests

def postRequest():
    BASE_URL='http://127.0.0.1:8000/api/'
    empRec={'eno':9,'ename':'Vijay','esal':2000.0,'eaddr':'cl'}
    j_data=json.dumps(empRec)
    resp=requests.post(BASE_URL,data=j_data)
    print(resp.status_code)
    print(resp.json())

def getRequest():
    BASE_URL = 'http://127.0.0.1:8000/stock1/'
    resp = requests.get(BASE_URL)
    print(resp.status_code)
    print(resp.json())

getRequest()
