from django.shortcuts import render
from secondapp.models import Employee
from secondapp.forms import EmployeeForm
from django.views.generic import View
from django.http import HttpResponse
import json


def view_cal(request):
    return render(request, 'secondapp/result.html')

def view_getEmployee(request):
    employeeInfo=Employee.objects.all()
    mydict={'employees':employeeInfo}
    return render(request,'secondapp/table.html',mydict)

# def EmployeeDetailsFunctionBased(request):
    # kk=Employee.objects.all().get(id=1)
    # emp_Data={
    # 'Id':1,
    # 'Name':'ABH',
    # 'Salary':1000,
    # 'Address':'Delhi'
    # }
    # json_Data=json.dumps(kk)
    # return HttpResponse(json_Data,content_type='application/json')
#
class EmployeeDetailsClassBased(View):

    def get(self,request,ID,*args,**kwargs):
        emp=Employee.objects.all().get(id=ID)
        emp_Data={
        'ID':emp.eno,
        'Name':emp.ename,
        'Salary':emp.esal,
        'Address':emp.eaddr,
        }
        json_Data=json.dumps(emp_Data)
        return HttpResponse(json_Data,content_type='application/json')

    def post(self,request,*args,**kwargs):
        # emp=Employee.objects.all().get(id=1)
        # emp_Data={
        # 'ID':emp.eno,
        # 'Name':emp.ename,
        # 'Salary':emp.esal,
        # 'Address':emp.eaddr,
        # }
        data=request.body
        cnvt_dict=json.loads(data)
        form=EmployeeForm(cnvt_dict)
        if form.is_valid():
            form.save(commit=True)
            json_Data=json.dumps({'msg':'Added Successfully!!'})
            return HttpResponse(json_Data,content_type='application/json')
        json_Data = json.dumps({'msg': 'Not added!!'})
        return HttpResponse(json_Data, content_type='application/json')