from django.contrib import admin
from secondapp.models import Employee
from secondapp.models import Stock,StockS,StockT,StockF,StockFF,CompleteStock
# Register your models here.

class EmployeeAdmin(admin.ModelAdmin):
    list_display = ['id','eno','ename','esal']

admin.site.register(Employee,EmployeeAdmin)
admin.site.register(Stock)
admin.site.register(StockS)
admin.site.register(StockT)
admin.site.register(StockF)
admin.site.register(StockFF)
admin.site.register(CompleteStock)