from django.db import models

# Create your models here.
class Employee(models.Model):
    eno = models.IntegerField()
    ename = models.CharField(max_length=30)
    esal = models.FloatField()
    eaddr = models.CharField(max_length=30)

class Stock(models.Model):
    sname = models.CharField(max_length=90)
    sprice =models.FloatField()
    srate = models.FloatField()
    svol = models.FloatField()
    sdel=models.FloatField()

class StockS(models.Model):
    sname = models.CharField(max_length=90)
    sprice =models.FloatField()
    srate = models.FloatField()
    svol = models.FloatField()
    sdel=models.FloatField()

class StockT(models.Model):
    sname = models.CharField(max_length=90)
    sprice =models.FloatField()
    srate = models.FloatField()
    svol = models.FloatField()
    sdel=models.FloatField()

class StockF(models.Model):
    sname = models.CharField(max_length=90)
    sprice = models.FloatField()
    srate = models.FloatField()
    svol = models.FloatField()
    sdel = models.FloatField()

class StockFF(models.Model):
    sname = models.CharField(max_length=90)
    sprice =models.FloatField()
    srate = models.FloatField()
    svol = models.FloatField()
    sdel=models.FloatField()

class CompleteStock(models.Model):
    sname = models.CharField(max_length=90)
    sprice_1 =models.FloatField()
    srate_1 = models.FloatField()
    svol_1 = models.FloatField()
    sdel_1=models.FloatField()
    sprice_2 = models.FloatField()
    srate_2 = models.FloatField()
    svol_2 = models.FloatField()
    sdel_2 = models.FloatField()
    sprice_3 = models.FloatField()
    srate_3 = models.FloatField()
    svol_3 = models.FloatField()
    sdel_3 = models.FloatField()
    sprice_4 = models.FloatField()
    srate_4 = models.FloatField()
    svol_4 = models.FloatField()
    sdel_4 = models.FloatField()
