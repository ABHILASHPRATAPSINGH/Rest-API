import base64
from wsgiref.util import FileWrapper

from django.shortcuts import render
from requests import Response
from secondapp.models import Employee
from secondapp.models import Stock,StockS,StockT,StockF,StockFF,CompleteStock
from secondapp import utility

from django.views.generic import View
from django.http import HttpResponse, JsonResponse
import json
import pandas
# ['Name', 'Price_1', 'Rate_1', 'Volume_1', 'Delivery_1', 'Price_2',
#        'Rate_2', 'Volume_2', 'Delivery_2', 'Price_3', 'Rate_3', 'Volume_3',
#        'Delivery_3', 'Price_4', 'Rate_4', 'Volume_4', 'Delivery_4', 'Price_5',
#        'Rate_5', 'Volume_5', 'Delivery_5']

def view_cal(request):
    # df=createMainDf()
    return render(request, 'secondapp/result.html')


def view_Stock(request):
    # print(sortPar)
    stock = CompleteStock.objects.all().order_by('-srate_1','-sdel_1').values()
    mydict = {'stock': stock}
    return render(request, 'secondapp/Stock.html',mydict)

def populate_Data(stockDataframe):
    #it populate database which is showing in HTML table
    for i in range(len(stockDataframe)):
        CompleteStock.objects.create(sname=stockDataframe.loc[i,'Name'],
                                     sprice_1=stockDataframe.loc[i,'Price_1'],sprice_2=stockDataframe.loc[i,'Price_2'],sprice_3=stockDataframe.loc[i,'Price_3'],sprice_4=stockDataframe.loc[i,'Price_4'],
                                     srate_1=stockDataframe.loc[i,'Rate_1'],srate_2=stockDataframe.loc[i,'Rate_2'],srate_3=stockDataframe.loc[i,'Rate_3'],srate_4=stockDataframe.loc[i,'Rate_4'],
                                     svol_1=stockDataframe.loc[i,'Volume_1'],svol_2=stockDataframe.loc[i,'Volume_2'],svol_3=stockDataframe.loc[i,'Volume_3'],svol_4=stockDataframe.loc[i,'Volume_4'],
                                     sdel_1=stockDataframe.loc[i,'Delivery_1'],sdel_2=stockDataframe.loc[i,'Delivery_2'],sdel_3=stockDataframe.loc[i,'Delivery_3'],sdel_4=stockDataframe.loc[i,'Delivery_4'])

def view_getEmployee(request):
    employeeInfo=Employee.objects.all()
    mydict={'employees':employeeInfo}
    return render(request,'secondapp/table.html',mydict)

def view_addStockToDB(request):

    StockFF.objects.all().delete()

    # all_stockFF=StockF.objects.all()
    # for stock in all_stockFF:
    #     StockFF.objects.create(sname=stock.sname,sprice=stock.sprice,srate=stock.srate,svol=stock.svol,sdel=stock.sdel)

    StockF.objects.all().delete()# delete dabaBase 4day
    all_stockF = StockT.objects.all()# popuate dataBase 4thday from 3rd database
    for stock in all_stockF:
        StockF.objects.create(sname=stock.sname, sprice=stock.sprice, srate=stock.srate, svol=stock.svol,sdel=stock.sdel)

    StockT.objects.all().delete() #delete database_3day
    all_stockT = StockS.objects.all() # populate database 3 from 2nd database
    for stock in all_stockT:
        StockT.objects.create(sname=stock.sname, sprice=stock.sprice, srate=stock.srate, svol=stock.svol,sdel=stock.sdel)

    StockS.objects.all().delete() #delete database 2nd
    all_stockS = Stock.objects.all() #populate database 2 from 1st database
    for stock in all_stockS:
        StockS.objects.create(sname=stock.sname, sprice=stock.sprice, srate=stock.srate, svol=stock.svol,sdel=stock.sdel)
    Stock.objects.all().delete() #delete database 1st

    #Start----------------populate 1st database------------------------------
    rate = utility.rCurrentStockPriceInfoWeb() #scraping current price data from financial site, return DF
    delivery = utility.rCurrentStockVolDelInfoWeb() #scraping current delivery data from financial site, return DF
    stock_data = utility.mergeData(rate, delivery) #merging price df and delivery df on the basis of name, return DF

    for i in range(len(stock_data)): #populating database 1
        Stock.objects.create(sname=stock_data.loc[i,'Name'], sprice=stock_data.loc[i,'Price_x'], srate=stock_data.loc[i,'Rate'], svol=stock_data.loc[i,'Volume_x'],sdel=stock_data.loc[i,'% Del'])
    #End----------------populate 1st database------------------------------

    # Start----------------populate main database------------------------------
    CompleteStock.objects.all().delete()# deleting main database which is showing on HTML
    mainDf=createMainDf() # meringing all databases into Main df, return DF
    populate_Data(mainDf) # populating main database which is showing on HTML.
    # End----------------populate main database------------------------------

    s = '<h1>Data added to database!!!</h1>'
    return HttpResponse(s)

def createDfFromDB(db,num): # creating old dataframe from old databases
    # s=Stock.objects.all()
    listOfStocks=[]
    for each_stock in list(db):
        inner_li=[]
        inner_li.append(each_stock.sname)
        inner_li.append(each_stock.sprice)
        inner_li.append(each_stock.srate)
        inner_li.append(each_stock.svol)
        inner_li.append(each_stock.sdel)
        listOfStocks.append(inner_li)
    df=pandas.DataFrame(listOfStocks,columns=['Name','Price_'+str(num),'Rate_'+str(num),'Volume_'+str(num),'Delivery_'+str(num)])
    return df

def createMainDf():
    DB1 = Stock.objects.all()
    DB2 = StockS.objects.all()
    DB3 = StockT.objects.all()
    DB4 = StockF.objects.all()
    # DB5 = StockFF.objects.all()

    DF1=  createDfFromDB(DB1,1)
    DF2 = createDfFromDB(DB2,2)
    DF3 = createDfFromDB(DB3,3)
    DF4 = createDfFromDB(DB4,4)
    # DF5 = createDfFromDB(DB5,5)

    # df = pandas.merge(DF1, DF2, on='Name', how='left')
    df=DF1.merge(DF2, on='Name').merge(DF3, on='Name').merge(DF4, on='Name')
    return df

class EmployeeDetailsClassBased(View):

    def get(self,request,*args,**kwargs):
        # 'emp=Employee.objects.get(id=1)
        pdfPath=r"C:\Users\DELL\PycharmProjects\djangoPro1\Day 1 Introduction and Placing Fingers.pdf"
        short_report = open(pdfPath, 'rb')
        fileWrapper=FileWrapper(short_report)
        encodedFileWrapper= base64.b64encode(short_report.read()).decode("utf-8")

        emp_Data={
        'Id':1,
        'Name':'CHI',
        'Salary':1000,
        'Address':'Ghaziabad'
        ,"file": encodedFileWrapper
        }
        #
        # d={}
        # d["file"]=encodedFileWrapper
        # return JsonResponse(d)
        # response = HttpResponse(fileWrapper, content_type='application/pdf')
        # return response

        json_Data=json.dumps(emp_Data)
        return HttpResponse(json_Data,content_type='application/json')

        # return HttpResponse(encodedFileWrapper)


# def EmployeeDetailsFunctionBased(request):
#     emp_Data={
#     'Id':1,
#     'Name':'ABH',
#     'Salary':1000,
#     'Address':'Delhi'
#     }
#     json_Data=json.dumps(emp_Data)
#     return HttpResponse(json_Data,content_type='application/json')
